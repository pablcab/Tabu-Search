import random

for _ in range(5):
    print(random.sample(range(5), 5))
