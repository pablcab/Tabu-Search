j = 0
for i in range(100):
    if i > 20:
        if i == 90:
            z = 0
            break
        elif i > 30:
            j += 1
            z = 2

print(i)
print(j)
print(z)
